package com.gotop.util;

public class constantsUtil {

	
}
