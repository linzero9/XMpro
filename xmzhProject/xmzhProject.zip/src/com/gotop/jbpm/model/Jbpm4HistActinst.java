package com.gotop.jbpm.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Jbpm4HistActinst implements Serializable {
    /**
     * null .
     * @abatorgenerated
     */
    private BigDecimal dbid;

    /**
     * null .
     * @abatorgenerated
     */
    private String classType;

    /**
     * null .
     * @abatorgenerated
     */
    private Long dbversion;

    /**
     * null .
     * @abatorgenerated
     */
    private BigDecimal hproci;

    /**
     * null .
     * @abatorgenerated
     */
    private String type;

    /**
     * null .
     * @abatorgenerated
     */
    private String execution;

    /**
     * null .
     * @abatorgenerated
     */
    private String activityName;

    /**
     * null .
     * @abatorgenerated
     */
    private Date start;

    /**
     * null .
     * @abatorgenerated
     */
    private Date end;

    /**
     * null .
     * @abatorgenerated
     */
    private BigDecimal duration;

    /**
     * null .
     * @abatorgenerated
     */
    private String transition;

    /**
     * null .
     * @abatorgenerated
     */
    private Long nextidx;

    /**
     * null .
     * @abatorgenerated
     */
    private BigDecimal htask;

    /**
     * null .
     * @abatorgenerated
     */
    public BigDecimal getDbid() {
        return dbid;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setDbid(BigDecimal dbid) {
        this.dbid = dbid;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getClassType() {
        return classType;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setClassType(String classType) {
        this.classType = classType;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public Long getDbversion() {
        return dbversion;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setDbversion(Long dbversion) {
        this.dbversion = dbversion;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public BigDecimal getHproci() {
        return hproci;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setHproci(BigDecimal hproci) {
        this.hproci = hproci;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getType() {
        return type;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getExecution() {
        return execution;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setExecution(String execution) {
        this.execution = execution;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getActivityName() {
        return activityName;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public Date getStart() {
        return start;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public Date getEnd() {
        return end;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public BigDecimal getDuration() {
        return duration;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setDuration(BigDecimal duration) {
        this.duration = duration;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getTransition() {
        return transition;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setTransition(String transition) {
        this.transition = transition;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public Long getNextidx() {
        return nextidx;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setNextidx(Long nextidx) {
        this.nextidx = nextidx;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public BigDecimal getHtask() {
        return htask;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setHtask(BigDecimal htask) {
        this.htask = htask;
    }
}