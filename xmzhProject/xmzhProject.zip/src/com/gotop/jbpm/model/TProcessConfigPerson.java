package com.gotop.jbpm.model;

import java.io.Serializable;

public class TProcessConfigPerson implements Serializable {
    /**
     * null .
     * @abatorgenerated
     */
    private Long id;

    /**
     * null .
     * @abatorgenerated
     */
    private Long processConfigId;

    /**
     * null .
     * @abatorgenerated
     */
    private String relationId;

    /**
     * null .
     * @abatorgenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public Long getProcessConfigId() {
        return processConfigId;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setProcessConfigId(Long processConfigId) {
        this.processConfigId = processConfigId;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public String getRelationId() {
        return relationId;
    }

    /**
     * null .
     * @abatorgenerated
     */
    public void setRelationId(String relationId) {
        this.relationId = relationId;
    }
}